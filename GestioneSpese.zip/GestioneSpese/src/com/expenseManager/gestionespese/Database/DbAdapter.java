package com.expenseManager.gestionespese.Database;

public class DbAdapter {

}
